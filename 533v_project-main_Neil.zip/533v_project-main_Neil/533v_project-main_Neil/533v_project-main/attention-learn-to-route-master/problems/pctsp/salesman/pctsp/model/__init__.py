# package model
#
# Copyright (c) 2018 Rafael Reis
#
"""
Package model - Models of Prize Collecting Travelling Salesman Problem

"""
__version__="1.0"
__author__ = "Rafael Reis <rafael2reis@gmail.com>"
